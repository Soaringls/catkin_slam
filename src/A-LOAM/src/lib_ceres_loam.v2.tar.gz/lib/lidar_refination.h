#pragma once
#include "data_center.h"
#include "timer.h"
#include "utility.h"

namespace ceres_loam {

const int laserCloudWidth = 21;
const int laserCloudHeight = 21;
const int laserCloudDepth = 11;

const int laserCloudNum =
    laserCloudWidth * laserCloudHeight * laserCloudDepth;  // 4851

class LidarRefination {
 public:
  std::shared_ptr<LidarRefination> LidarMappingPtr;
  std::shared_ptr<const LidarRefination> LidarMappingConstPtr;

 public:
  LidarRefination();
  ~LidarRefination() = default;

  void Process();
  const Eigen::Quaterniond GetQuaternion() { return q_w_curr_; }
  const Eigen::Vector3d GetPos() { return t_w_curr_; }
  const PointCloudPtr GenerateWholeMap();

 private:
  void allocateMemory();
  void accessData();
  void accessAvailableCubicNum(int &scan_valid_num, int &sub_scan_valid_num);
  void pointAssociateToMap(PointType const *const pi, PointType *const po);
  void transformUpdate();
  void transformAssociateToMap();

  void addFeatureCloudtoPool();

  void prepareData(const int featuremap_scans);
  void calculateTransformation();
  void calculateTransformationSurf(ceres::Problem &problem,
                                   ceres::LossFunction *loss_function);
  void calculateTransformationCorner(ceres::Problem &problem,
                                     ceres::LossFunction *loss_function);
  void updateOptimizedResult();
  void downSampleCornerSurfArray(const int scan_valid_num);

 private:
  int laserCloudCenWidth;
  int laserCloudCenHeight;
  int laserCloudCenDepth;

  // global pose of lidar-odom assign by odom
  Eigen::Vector3d t_wodom_curr;
  Eigen::Quaterniond q_wodom_curr;
  // intermediate variable
  Eigen::Vector3d t_wmap_wodom;
  Eigen::Quaterniond q_wmap_wodom;

  pcl::VoxelGrid<PointType> voxel_filter_corner_;
  pcl::VoxelGrid<PointType> voxel_filter_surf_;
  PointCloudPtr feature_scan_corner_;
  PointCloudPtr feature_scan_corner_filtered_;
  PointCloudPtr feature_scan_surf_;
  PointCloudPtr feature_scan_surf_filtered_;
  PointCloudPtr cloud_full_res;  // useless

  // surround points in map to build tree
  int scans_valid_indices[125];
  int subscans_valid_indices[125];
  PointCloudPtr corner_map;
  PointCloudPtr surf_map;
  // kd-tree
  pcl::KdTreeFLANN<PointType>::Ptr kdtree_corner_map_;
  pcl::KdTreeFLANN<PointType>::Ptr kdtree_surf_map_;
  std::vector<int> neighbor_pts_indices;
  std::vector<float> neighbor_pts_dist;

  // final optimized global pose
  double parameters[7];
  Eigen::Vector3d t_w_curr_;     //(parameters);
  Eigen::Quaterniond q_w_curr_;  //(parameters);

  // points in every cube
  PointCloudPtr corners_pool[laserCloudNum];
  PointCloudPtr surfs_pool[laserCloudNum];
  PointCloudPtr globis_map;
};
}  // namespace ceres_loam