#pragma once
#include "data_center.h"
#include "timer.h"
#include "utility.h"

namespace ceres_loam {

const int laserCloudWidth = 21;
const int laserCloudHeight = 21;
const int laserCloudDepth = 11;

const int laserCloudNum =
    laserCloudWidth * laserCloudHeight * laserCloudDepth;  // 4851

class LidarMapping {
 public:
  std::shared_ptr<LidarMapping> LidarMappingPtr;
  std::shared_ptr<const LidarMapping> LidarMappingConstPtr;

 public:
  LidarMapping();
  ~LidarMapping() = default;

  void Process();
  const Eigen::Quaterniond GetQuaternion() { return q_w_curr; }
  const Eigen::Vector3d GetPos() { return t_w_curr; }
  const PointCloudPtr GetAllMap() { return laserCloudMap; }

 private:
  void allocateMemory();
  void accessData();
  void pointAssociateToMap(PointType const *const pi, PointType *const po);
  void transformUpdate();
  void transformAssociateToMap();

 private:
  int laserCloudCenWidth;
  int laserCloudCenHeight;
  int laserCloudCenDepth;

  int laserCloudValidInd[125];
  int laserCloudSurroundInd[125];

  // global pose of lidar-odom
  Eigen::Vector3d t_wodom_curr;     // assign by odom
  Eigen::Quaterniond q_wodom_curr;  // assign by odom

  Eigen::Vector3d t_wmap_wodom;
  Eigen::Quaterniond q_wmap_wodom;

  // final optimized global pose
  double parameters[7];
  Eigen::Vector3d t_w_curr;     //(parameters);
  Eigen::Quaterniond q_w_curr;  //(parameters);

  pcl::VoxelGrid<PointType> downSizeFilterCorner;
  pcl::VoxelGrid<PointType> downSizeFilterSurf;

  PointCloudPtr laserCloudCornerLast;
  PointCloudPtr laserCloudSurfLast;
  PointCloudPtr laserCloudFullRes;  // useless

  PointType pointOri, pointSel;
  std::vector<int> pointSearchInd;
  std::vector<float> pointSearchSqDis;

  // points in every cube
  PointCloudPtr laserCloudCornerArray[laserCloudNum];
  PointCloudPtr laserCloudSurfArray[laserCloudNum];
  // surround points in map to build tree
  pcl::PointCloud<PointType>::Ptr laserCloudCornerFromMap;
  pcl::PointCloud<PointType>::Ptr laserCloudSurfFromMap;

  // kd-tree
  pcl::KdTreeFLANN<PointType>::Ptr kdtreeCornerFromMap;
  pcl::KdTreeFLANN<PointType>::Ptr kdtreeSurfFromMap;

  PointCloudPtr laserCloudMap;
};
}  // namespace ceres_loam